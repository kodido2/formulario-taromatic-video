/* JavaScript movido desde tu código original */
/* Aquí colocarías tu script final */